Here you can find the workshop materials.

Please **download** the zip folder at <https://github.com/DiXiT-eu/Digital-Scholarly-EditionsGR-workshop/tree/master/materials.zip> and **unzip** it (option Extract or similar in the File menu).

Remember where you saved these materials. A good place is in your Home or MyDocuments directories ; less good places are the Desktop or Download folder.


<h3>Note down that this folder may contain third-party material. Especially for the Tsirkas- Papaioannou correspondence its availability and use is restricted only for educational purpose during the workshop. </h3>








